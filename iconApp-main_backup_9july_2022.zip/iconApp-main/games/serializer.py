"""import required module"""
from rest_framework import serializers
from IGL_account.models import User
from .models import Platform, Game, Tournament, StageType, Stage, Group, Round, Match, MatchParticipant, TrophyCategory,\
    BadgesCategory, UserBadges, Challenges, EarnedCoins, Friends, \
    LoginStreak, Tournaments
from iconApi.settings.default import base_url


class PlatformSerializer(serializers.ModelSerializer):
    """ A class PlatformSerializer Serializer is used for PlatformModel """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your PlatformModel fields"""

        model = Platform
        fields = (
            'id', 'name', 'manufacturer', 'model',)


class GameSerializer(serializers.ModelSerializer):
    """ A classGameSerializer Serializer is used for Game Model """
    display_image = serializers.SerializerMethodField()

    class Meta:
        """ Metaclass is used for changed the behaviour of Your Game Model fields"""
        model = Game
        fields = (
            'id', 'display_name', 'slug', 'full_name', 'short_name', 'platforms', 'display_image',)

    def get_display_image(self, obj):
        if obj:
            a = base_url + obj.display_image.url
            return a
        return ''


class TournamentSerializer(serializers.ModelSerializer):
    """ A class TournamentSerializer Serializer is used for  Tournament Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your   Tournament Model fields"""
        model = Tournament
        fields = (
            'name', 'full_name', 'slug', 'game', 'size', 'scheduled_date_start', 'scheduled_date_end',)


class StageTypeSerializer(serializers.ModelSerializer):
    """ A class  StageTypeSerializer Serializer is used for   StageType Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your   StageType Model fields"""
        model = StageType
        fields = ('name',)


class StageSerializer(serializers.ModelSerializer):
    """ A class  StageSerializer Serializer is used for  G Stage Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your   Stage Model fields"""
        model = Stage
        fields = ('name', 'tournament', 'number', 'stage_type', 'is_closed',)


class GroupSerializer(serializers.ModelSerializer):
    """ A class GroupSerializer Serializer is used for  Group Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  Group Model fields"""
        model = Group
        fields = ('name', 'tournament', 'closed',)


class RoundSerializer(serializers.ModelSerializer):
    """ A class RoundSerializer is used for  Match Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  Round Model fields"""
        model = Round
        fields = ('tournament', 'stage', 'group', 'number', 'start_datetime', 'end_datetime',)


class MatchSerializer(serializers.ModelSerializer):
    """ A MatchSerializer Serializer is used for  Match Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  Match Model fields"""
        model = Match
        fields = (
            'tournament', 'round', 'stage', 'group', 'number', 'scheduled_datetime', 'start_datetime', 'end_datetime',
        )


class MatchParticipantSerializer(serializers.ModelSerializer):
    """ A class MatchParticipant Serializer is used for MatchParticipant Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your MatchParticipant Model fields"""
        model = MatchParticipant
        fields = ('user', 'tournament', 'match', 'checked_in_at',)


class TrophyCategorySerializer(serializers.ModelSerializer):
    """ A TrophyCategory Serializer is used for TrophyCategory Model """
    badges_image = serializers.SerializerMethodField()

    class Meta:
        """ Metaclass is used for changed the behaviour of Your TrophyCategory Model fields"""

        model = TrophyCategory
        fields = ('id', 'category_name', 'badges_image')

    def get_badges_image(self, obj):
        if obj:
            a = base_url + obj.badges_image.url
            return a
        return ''


class BadgesCategorySerializer(serializers.ModelSerializer):
    """ A BadgesCategory Serializer is used for BadgesCategory Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  BadgesCategory Model fields"""

        model = BadgesCategory
        depth = 1
        fields = ('id', 'category_id', 'badge_type', 'display_name',)


class ChallengesSerializer(serializers.ModelSerializer):
    """ A Challenges Serializer is used for ChallengesSerializer Model """

    wins20_image = serializers.SerializerMethodField()

    # wins50_image = serializers.SerializerMethodField()
    # wins100_image = serializers.SerializerMethodField()

    class Meta:
        model = Challenges
        fields = ("id", 'wins20', 'wins50', 'wins100', 'wins20_image', 'wins50_image', 'wins100_image')

    def wins20_image(self, obj):
        if obj:
            a = base_url + obj.wins20_image.url
            return a
        return ''

    def wins50_image(self, obj):
        if obj:
            a = base_url + obj.wins50_image.url
            return a
        return ''

    def wins100_image(self, obj):
        if obj:
            a = base_url + obj.wins100_image.url
            return a
        return ''


class TournamentsSerializer(serializers.ModelSerializer):
    """ A Tournaments Serializer is used for TournamentsSerializer Model """

    wins1_image = serializers.SerializerMethodField()

    class Meta:
        model = Tournaments
        fields = ("id", 'wins1', 'wins5', 'wins10', 'wins1_image', 'wins5_image', 'wins10_image')

    def wins1_image(self, obj):
        if obj:
            a = base_url + obj.wins1_image.url
            return a
        return ''


class EarnedCoinsSerializer(serializers.ModelSerializer):
    """ A EarnedCoins Serializer is used for EarnedCoinsSerializer Model """

    earn500_image = serializers.SerializerMethodField()

    class Meta:
        model = EarnedCoins
        fields = ("id", 'earn500', 'earn1000', 'earn10000', 'earn500_image', 'earn1000_image', 'earn10000_image')

    def earn500_image(self, obj):
        if obj:
            a = base_url + obj.earn500_image.url
            return a
        return ''


class FriendSerializer(serializers.ModelSerializer):
    """ A Friends Serializer is used for FriendSerializer Model """

    add5_image = serializers.SerializerMethodField()

    class Meta:
        model = Friends
        fields = ("id", 'add5', 'add10', 'add20', 'add5_image', 'add10_image', 'add20_image')

    def add5_image(self, obj):
        if obj:
            a = base_url + obj.add5_image.url
            return a
        return ''


class LoginStreakSerializer(serializers.ModelSerializer):
    """ A LoginStreak Serializer is used for LoginStreakSerializer Model """
    log5 = serializers.SerializerMethodField()

    class Meta:
        model = LoginStreak
        fields = ("id", 'log5', 'log10', 'log20', 'log5_image', 'log10_image', 'log20_image')

    def log5(self, obj):
        if obj:
            a = base_url + obj.log5.url
            return a
        return ''


class UserBadgesSerializer(serializers.ModelSerializer):
    """ A UserBadges Serializer is used for UserBadgesSerializer Model """
    challenges = ChallengesSerializer()
    tournaments = TournamentsSerializer()
    earned_coins = EarnedCoinsSerializer()
    Friend = FriendSerializer()
    login_streak = LoginStreakSerializer()

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  UserBadges Model fields"""
        model = UserBadges
        fields = ('id', 'user_id', 'challenges', 'tournaments', 'earned_coins', 'Friend', 'login_streak',)

