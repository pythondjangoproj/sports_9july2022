"""Import Required Module"""
from django.shortcuts import render
from rest_framework.response import Response
from IGL_account.models import User
from .serializer import PlatformSerializer, GameSerializer, TournamentSerializer, StageTypeSerializer, StageSerializer, \
    GroupSerializer, RoundSerializer, MatchSerializer, MatchParticipantSerializer, TrophyCategorySerializer, \
    BadgesCategorySerializer, UserBadgesSerializer

from .models import Platform, Game, Tournament, StageType, Stage, Group, Round, Match, MatchParticipant, BadgesCategory, \
    TrophyCategory, UserBadges
from rest_framework import generics
import logging

logger = logging.getLogger(__name__)


# Create your views here.

class PlatformAPI(generics.GenericAPIView):
    serializer_class = PlatformSerializer

    def get(self, request, pk=None):
        """return a list of all StageType for specfic Platform
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to Platform id.
             """
        user_id = pk
        try:
            if user_id is not None:
                user = Platform.objects.get(id=user_id)
                serializer = PlatformSerializer(user)
                return Response({"data": serializer.data})
            user = Platform.objects.all()
            serializer = PlatformSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('platform error Information incoming!', e)
            return Response({"message": "Unable to create platform"})

    def post(self, request):
        """Create List of record for Platform
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = PlatformSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('error with platform create Information incoming!', e)
            return Response({"message": "Unable to create platform"})

    def delete(self, request, pk):
        """delete a single record for Platform,when request page/url requested the user
             :params pk pass the  Platform record id"""
        platform = Platform(pk)
        platform.delete()
        return Response({"msg": "Platform is deleted"})


class GameAPI(generics.GenericAPIView):
    serializer_class = GameSerializer

    def post(self, request):
        """Create List of record for Game
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = GameSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('game error Information incoming!', e)
            return Response({"message": "Unable to create Game"})

    def get(self, request, pk=None):
        """return a list of all StageType for specfic Game
             :parm request:object to pass state,WHEN page/url requested by user.
             parm pk:pass to Tournament id.
                """
        platform_id = pk
        try:
            if platform_id is not None:
                games = Game.objects.filter(platforms__in=[platform_id])
                serializer = GameSerializer(games, many=True)
                return Response({"data": serializer.data})
            user = Game.objects.all()
            serializer = GameSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('game error Information incoming!', e)
            return Response({"message": "Unable to get the details of Game"})

    def delete(self, request, pk):
        """delete a single record for Game,when request page/url requested the user
                             :params pk pass the  Game record id"""
        game = Game(pk)
        game.delete()
        return Response({"msg": "game is deleted"})


class TournamentAPI(generics.GenericAPIView):
    serializer_class = TournamentSerializer

    def post(self, request):
        """Create List of record for Tournament
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = TournamentSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('tournament error Information incoming!', e)
            return Response({"message": "Unable to create the Tournament details"})

    def get(self, request, pk=None):
        """return a list of all StageType for specfic Tournament
            :parm request:object to pass state,WHEN page/url requested by user.
             parm pk:pass to Tournament id.
                """
        user_id = pk
        try:
            if user_id is not None:
                user = Tournament.objects.get(id=user_id)
                serializer = TournamentSerializer(user)
                return Response({"data": serializer.data})
            user = Tournament.objects.all()
            serializer = TournamentSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Tournament Information incoming!', e)
            return Response({"message": "No tournament registered"})


class StageTypeAPI(generics.GenericAPIView):
    serializer_class = StageTypeSerializer

    def post(self, request):
        """Create List of record for StageType
         :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = StageTypeSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('stage type error Information incoming!', e)
            return Response({"message": "Unable to create stage types"})

    def get(self, request, pk=None):
        """return a list of all StageType for specfic StageType
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to StageType id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = StageType.objects.get(id=user_id)
                serializer = StageTypeSerializer(user)
                return Response({"data": serializer.data})
            user = StageType.objects.all()
            serializer = StageTypeSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('stage type error Information incoming!', e)
            return Response({"message": "Unable to get the details of stage type"})


class StageAPI(generics.GenericAPIView):
    serializer_class = StageSerializer

    def post(self, request):
        """Create List of record for Stage
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = StageSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('stage error Information incoming!', e)
            return Response({"message": "Unable to update the Team member registration"})

    def get(self, request, pk=None):
        """return a list of all Round for specfic Stage
          :parm request:object to pass state,WHEN page/url requested by user.
          parm pk:pass to Stage id.
          """
        user_id = pk
        try:
            if user_id is not None:
                user = Stage.objects.get(id=user_id)
                serializer = StageSerializer(user)
                return Response({"data": serializer.data})
            user = Stage.objects.all()
            serializer = StageSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('stage get error Information incoming!', e)
            return Response({"message": "Unable to find team member details"})


class GroupAPI(generics.GenericAPIView):
    serializer_class = GroupSerializer

    def post(self, request):
        """Create List of record for Group
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = GroupSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('group Information incoming!', e)
            return Response({"message": "Unable to create group"})

    def get(self, request, pk=None):
        """return a list of all Round for specfic Group
        :parm request:object to pass state,WHEN page/url requested by user.
        parm pk:pass to Match id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = Group.objects.get(id=user_id)
                serializer = GroupSerializer(user)
                return Response({"data": serializer.data})
            user = Group.objects.all()
            serializer = GroupSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('group Information incoming!', e)
            return Response({"message": "Unable to get the group details"})


class RoundAPI(generics.GenericAPIView):
    serializer_class = RoundSerializer

    def post(self, request):
        """Create List of record for Round
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = RoundSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to define the Round"})

    def get(self, request, pk=None):
        """return a list of all Round for specific Round
        :parm request:object to pass state,WHEN page/url requested by user.
        parm pk:pass to Match id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = Round.objects.get(id=user_id)
                serializer = RoundSerializer(user)
                return Response({"data": serializer.data})
            user = Round.objects.all()
            serializer = RoundSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get Round details"})


class MatchAPI(generics.GenericAPIView):
    serializer_class = MatchSerializer

    def post(self, request):
        """Create List of record for Match
            :parm request:object to pass to state when request page/url requested the user
             """
        try:
            serializer = MatchSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to create Matches"})

    def get(self, request, pk=None):
        """return a list of all Match for specfic Match
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to Match id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = Match.objects.get(id=user_id)
                serializer = MatchSerializer(user)
                return Response({"data": serializer.data})
            user = Match.objects.all()
            serializer = MatchSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get Match details"})


class MatchParticipantAPI(generics.GenericAPIView):
    serializer_class = MatchParticipantSerializer

    def post(self, request):
        """Create List of record for MatchParticipant
            :parm request:object to pass to state when request page/url requested the user
            """
        try:
            serializer = MatchParticipantSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('Match Information incoming!', e)
            return Response({"message": "Unable to create MatchParticipant for Matches"})

    def get(self, request, pk=None):
        """return a list of all MatchParticipant for specfic MatchParticipant
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to MatchParticipant id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = MatchParticipant.objects.get(id=user_id)
                serializer = MatchParticipantSerializer(user)
                return Response({"data": serializer.data})
            user = MatchParticipant.objects.all()
            serializer = MatchParticipantSerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('match Information incoming!', e)
            return Response({"message": "Unable to get MatchParticipant details with matches"})


class TrophyCategoryAPI(generics.GenericAPIView):
    serializer_class = TrophyCategorySerializer

    def post(self, request):
        """Create List of record for TrophyCategory
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = TrophyCategorySerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as e:
            logging.info('trophy category Information incoming!', e)
            return Response({"message": "Unable to create trophy category"})

    def get(self, request, pk=None):
        """return a list of all TrophyCategory for specific TrophyCategory
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to TrophyCategory id.
            """
        user_id = pk
        try:
            if user_id is not None:
                user = TrophyCategory.objects.get(id=user_id)
                serializer = TrophyCategorySerializer(user)
                return Response({"data": serializer.data})
            user = TrophyCategory.objects.all()
            serializer = TrophyCategorySerializer(user, many=True)
            return Response({"data": serializer.data})

        except Exception as e:
            logging.info('trophy Information incoming!', e)
            return Response({"message": "Unable to get the Trophy category details"})

    def put(self, request, pk=id):
        """update a list of record for TrophyCategory,when request page/url requested the user
                       :params pk pass the  TrophyCategory record id"""

        try:
            user_id = pk
            user = TrophyCategory.objects.get(id=user_id)
            serializer = TrophyCategorySerializer(user, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"msg": "TrophyCategory badges is updated"})
        except Exception as e:
            logging.info('Trophy category Information incoming!', e)
            return Response({"message": "Unable to perform the update trophy category details"})

    def delete(self, request, pk):
        """delete a single record for TrophyCategory,when request page/url requested the user
            :params pk pass the  TrophyCategory record id"""
        trophy = TrophyCategory(pk)
        trophy.delete()
        return Response({"msg": "TrophyCategory badges is deleted"})


class BadgesCategoryAPI(generics.GenericAPIView):
    serializer_class = BadgesCategorySerializer

    def post(self, request):
        """Create List of record for BadgesCategory
            :parm request:object to pass to state when request page/url requested the user
                """
        try:
            serializer = BadgesCategorySerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except:
            logging.info('Information incoming!')
            return Response({"message": "Unable to create the BadgesCategory details"})

    def get(self, request, pk=None):
        """return a list of all UserTrophyCase for specfic BadgesCategory
            :parm request:object to pass state,WHEN page/url requested by user.
            parm pk:pass to BadgesCategory id.
             """
        user_id = pk
        try:
            if user_id is not None:
                user = BadgesCategory.objects.get(id=user_id)
                serializer = BadgesCategorySerializer(user)
                return Response({"data": serializer.data})
            user = BadgesCategory.objects.all()
            serializer = BadgesCategorySerializer(user, many=True)
            return Response({"data": serializer.data})
        except Exception as e:
            logging.info('badges category Information incoming!', e)
            return Response({"message": "Unable to get the BadgesCategory details"})

    def put(self, request, pk=id):
        """update a list of record for BadgesCategory,when request page/url requested the user
            :params pk pass the  BadgesCategory record id"""
        try:
            user_id = pk
            user = BadgesCategory.objects.get(id=user_id)
            serializer = BadgesCategorySerializer(user, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"msg": "BadgesCategory badges is updated"})
        except Exception as e:
            logging.info('badges category Information incoming!', e)
            return Response({"message": "Unable to perform the update Badges category details"})

    def delete(self, request, pk):
        """delete a single record for BadgesCategory,when request page/url requested the user
                      :params pk pass the  BadgesCategory record id"""

        badges = BadgesCategory(pk)
        badges.delete()
        return Response({"msg": "BadgesCategory badges is deleted"})


class UserBadgesAPI(generics.GenericAPIView):
    serializer_class = UserBadgesSerializer

    def post(self, request):
        try:
            # user = User.objects.get(data=request.user)
            serializer = UserBadgesSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({"data": serializer.data})
        except Exception as ex:
            print(str(ex))

    def get(self, request, pk=None):
        user_id = pk
        if user_id is not None:
            user = UserBadges.objects.filter(user_id=user_id)
            serializer = UserBadgesSerializer(user, many=True)
            return Response({"data": serializer.data})

        user = UserBadges.objects.all()
        serializer = UserBadgesSerializer(user, many=True)
        return Response({"data": serializer.data})
