from django.urls import path
from Admin_app.views import UserOtpView, AdminLoginView, AdminProfileView, AdminRegistrationView, TournamentFormateAPI, TournamentSetupAPI, MyRegisterTournaments, IconDetailsAPI


urlpatterns = [
    path('admin_login/', AdminLoginView.as_view(), name='admin_login'),
    path('otp/', UserOtpView.as_view(), name='otp'),
    path('admin_profile/', AdminProfileView.as_view(), name='admin_profile'),
    path('admin_register/', AdminRegistrationView.as_view(), name='admin_register'),
    path('tournament_details/', TournamentSetupAPI.as_view(), name='tournament_details'),
    path('tournament_format/', TournamentFormateAPI.as_view(), name='tournament_format'),
    path('registered_tournament/', MyRegisterTournaments.as_view(), name='registered_tournament'),
    path('registered_tournament/<int:pk>/', MyRegisterTournaments.as_view(), name='registered_tournament'),
    path('team_page/', IconDetailsAPI.as_view(), name='team_page'),
    path('team_page/<int:pk>/', IconDetailsAPI.as_view(), name='team_page'),
]
