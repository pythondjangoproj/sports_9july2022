from django.contrib import admin
from .models import TournamentSetupIn, TournamentFormate, MyTimezoneTableIn, TournamentLengthIn, TournamentFormate, AddIcon, BlogCategory, BlogPost, VideoManagement

# Register your models here.

admin.site.register(TournamentFormate)
admin.site.register(MyTimezoneTableIn)
admin.site.register(TournamentLengthIn)
admin.site.register(TournamentSetupIn)
admin.site.register(AddIcon)
admin.site.register(BlogCategory)
admin.site.register(BlogPost)
admin.site.register(VideoManagement)

