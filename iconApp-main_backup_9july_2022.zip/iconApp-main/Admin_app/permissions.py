from rest_framework.permissions import BasePermission
from django.db.models import Q

class GamePlayAdminPermissions(BasePermission):
    def has_permission(self, request, view):
        if request.user and request.user.groups.filter(Q(name='GAMEPLAY ADMIN') | Q(name='SUPER ADMIN')):
            return True
        return False


class OperationAdminPermissions(BasePermission):

    def has_permission(self, request, view):
        if request.user and request.user.groups.filter(Q(name='OPERATIONAL ADMIN') | Q(name='SUPER ADMIN')):
            return True
        return False


class UserAdminPermissions(BasePermission):

    def has_permission(self, request, view):
        if request.user and request.user.groups.filter(Q(name='USER ADMIN') | Q(name='SUPER ADMIN')):
            return True
        return False


class SuperAdminPermissions(BasePermission):

    def has_permission(self, request, view):
        if request.user and request.user.groups.filter(name='SUPER ADMIN'):
            return True
        return False


class IconAdminPermissions(BasePermission):

    def has_permission(self, request, view):
        if request.user and request.user.groups.filter(Q(name='ICON ADMIN') | Q(name='SUPER ADMIN')):
            return True
        return False
