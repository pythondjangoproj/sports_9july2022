"""import required module"""
from rest_framework.views import APIView
from IGL_account.models import User
from .serializers import UserOtpSerializer, AdminLoginSerializer, AdminProfileSerializer, AdminRegistrationSerializer, TournamentSetupSerializer, AddIconSerializer, TournamentFormateSerializer, AddIconsSerializer, BlogCategorySerializer, BlogPostSerializer, VideoManagementSerializer, TournamentLengthSerializer
from django.contrib.auth import authenticate
from django.contrib.auth.models import Group
from .models import TournamentSetupIn, TournamentFormate, AddIcon, TournamentLengthIn, BlogCategory, BlogPost, VideoManagement
from rest_framework.response import Response
import logging
from Admin_app.permissions import GamePlayAdminPermissions, SuperAdminPermissions, IconAdminPermissions, OperationAdminPermissions
from IGL_account.renderers import UserRenderer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
from rest_framework import generics, viewsets, routers
import random
from iconApi.settings import default
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
# Create your views here.


logger = logging.getLogger(__name__)

#Craete Default Router

router = routers.DefaultRouter()

def get_tokens_for_user(user):
    """Generate Token Manually"""
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class UserOtpView(APIView):
    """To perform the Otp operation sending on mail"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            email = request.data.get('email')
            if User.objects.filter(email=email).exists():
                serializer = UserOtpSerializer(data=request.data)
                if serializer.is_valid():
                    email = serializer.data.get('email')
                    otp = random.randint(100000, 999999)
                    link = str(otp)
                    plaintext = "test email"
                    htmly = get_template('Admin_app/verification-mail.html')
                    otp_link = {'link': link}
                    subject, from_email, to = 'One time password', default.EMAIL_HOST_USER, email
                    text_content = plaintext
                    html_content = htmly.render(otp_link)
                    msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
                    msg.attach_alternative(html_content, "text/html")
                    msg.send()
                    return Response({"status": True, "otp": otp}, status=status.HTTP_200_OK)
            else:
                return Response({'message': 'Unable to send OTP with given credential'},
                                status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to send OTP with given credential"}, status=status.HTTP_404_NOT_FOUND)


class AdminLoginView(APIView):
    """To perform the Otp operation sending on mail
       :parm request: object to pass to state when request page/url requested the user"""
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            user = User.objects.get(email=request.data.get('email'))
            if user.groups.all().exists():
                serializer = AdminLoginSerializer(data=request.data)
                if serializer.is_valid():
                    email = serializer.data.get('email')
                    password = serializer.data.get('password')
                    user = authenticate(email=email, password=password)
                    if user is not None:
                        token = get_tokens_for_user(user)
                        return Response({'token': token, 'msg': 'Login Success'}, status=status.HTTP_200_OK)
                    else:
                        return Response({'errors': {'non_field_errors': ['Email or Password is not Valid']}},
                                        status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({"status": False, "error": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to perform login operation with given credential"}, status=status.HTTP_404_NOT_FOUND)


class AdminProfileView(APIView):
    """To perform the Login operation for Admin User's
           :parm request: object to pass to state when request page/url requested the user"""
    permission_classes = [IsAuthenticated]
    renderer_classes = [UserRenderer]

    def get(self, request, format=None):
        try:
            serializer = AdminProfileSerializer(request.user)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to get the Admin user Record"}, status=status.HTTP_404_NOT_FOUND)


class AdminRegistrationView(APIView):
    """To perform the Admin user registration
       :parm request: object to pass to state when request page/url requested the user"""
    permission_classes = (SuperAdminPermissions,)
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        try:
            get_group = request.user.groups.all().values_list('name', flat=True)
            if 'SUPER ADMIN' in get_group:
                group_name = request.data.get('group')
                serializer = AdminRegistrationSerializer(data=request.data)
                if serializer.is_valid():
                    user = serializer.save()
                    add_group = Group.objects.get(name=group_name)
                    user.groups.add(add_group)
                    token = get_tokens_for_user(user)
                    return Response({'token': token, 'msg': 'Registration Successful'}, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({'msg': 'Request user is not Super Admin'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            logging.info('Information incoming!', e)
            return Response({"message": "Unable to registered the user details"}, status=status.HTTP_400_BAD_REQUEST)



class MyRegisterTournaments(generics.GenericAPIView):

    def get(self, request, pk=None):
        user_id = pk
        if user_id is None:
            return Response({"message": "Please provide user_id"})
        return Response({"message": "No registered tournaments"})


class TournamentSetupViewSets(viewsets.ModelViewSet):
    permission_classes = (GamePlayAdminPermissions,)
    queryset = TournamentSetupIn.objects.all()
    serializer_class = TournamentSetupSerializer


router.register('tournament_setup', TournamentSetupViewSets)


class TournamentSetupAPI(generics.GenericAPIView):

    def get(self, request):
        data = TournamentSetupIn.objects.all()
        serializer = TournamentSetupSerializer(data, many=True)
        return Response({'data': serializer.data}, status=status.HTTP_200_OK)


class TournamentFormateAPI(generics.GenericAPIView):
    """To fetch the details of Tournament format
       :parm request: object to pass to state when request page/url requested the user"""
    serializer_class = TournamentFormateSerializer
    permission_classes = (GamePlayAdminPermissions,)

    def get(self, request):

        tournament_formate_data = TournamentFormate.objects.all()
        serializer = TournamentFormateSerializer(tournament_formate_data, many=True)
        return Response({"data": serializer.data}, status=status.HTTP_200_OK)


class TournamentLengthViewSets(viewsets.ModelViewSet):
    queryset = TournamentLengthIn.objects.all()
    serializer_class = TournamentLengthSerializer


router.register('tournament_length', TournamentLengthViewSets)


class AddIconViewSets(viewsets.ModelViewSet):
    permission_classes = (IconAdminPermissions,)
    queryset = AddIcon.objects.all()
    serializer_class = AddIconsSerializer


router.register('addicon', AddIconViewSets)


class IconDetailsAPI(generics.GenericAPIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request, pk=None):
        try:
            team_page_id = pk
            if team_page_id:
                team_page_data = AddIcon.objects.get(id=team_page_id)
                serializer = AddIconsSerializer(team_page_data)
                return Response({'data': serializer.data}, status=status.HTTP_200_OK)
            team_page_data = AddIcon.objects.all()
            serializer = AddIconsSerializer(team_page_data, many=True)
            return Response({'data': serializer.data}, status=status.HTTP_200_OK)
        except Exception as e:
            logging.info('Information comming',e)
            return Response({'message': "Unable to get details of team page"})


class BlogCategoryViewSet(viewsets.ModelViewSet):
    permission_classes = (OperationAdminPermissions,)
    queryset = BlogCategory.objects.all()
    serializer_class = BlogCategorySerializer


router.register(r'blog_category', BlogCategoryViewSet, basename='blog_category')


class BlogPostViewSets(viewsets.ModelViewSet):
    permission_classes = (OperationAdminPermissions,)
    queryset = BlogPost.objects.all()
    serializer_class = BlogPostSerializer


router.register(r'blog_post', BlogPostViewSets, basename='blog_post')


class VideoManagementViewSet(viewsets.ModelViewSet):
    permission_classes = (OperationAdminPermissions,)
    queryset = VideoManagement.objects.all()
    serializer_class = VideoManagementSerializer


router.register(r'video_management', VideoManagementViewSet, basename='video_management')
