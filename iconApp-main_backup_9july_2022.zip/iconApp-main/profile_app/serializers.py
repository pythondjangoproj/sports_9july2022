"""import required module"""
from .models import UserPlatform, UserGame, UserMatchParticipant, GetUserSubmit, IGLNotification, \
    GlobalIndexHierarchy, GlobalIndex, PGIUserSubmit, UserIGLNotification, UserTrophyCase, CompleteProfile, \
    FriendRequest
from IGL_account.models import User
from rest_framework import serializers
from icon.models import Icon
from games.models import Platform, Game
from games.serializer import PlatformSerializer, GameSerializer
from icon.serializer import IconSerializer


class UserPlatformSerializer(serializers.ModelSerializer):
    """ A class UserPlatformSerializer is used for  UserPlatform Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your UserPlatform Model fields"""
        model = UserPlatform
        fields = (
            "id", "user_id", 'platforms',)


class UserGameSerializer(serializers.ModelSerializer):
    """ A class UserGameSerializer is used for  Tournament Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your UserGame Model fields"""
        model = UserGame
        fields = (
            "userplatform_id", 'gammer_tag', 'game', 'display_image',)


class UserMatchParticipantSerializer(serializers.ModelSerializer):
    """ A class UserMatchParticipantSerializer is used for  UserMatchParticipant Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your UserMatchParticipant Model fields"""
        model = UserMatchParticipant
        fields = (
            "usermatchparticipant_id", 'tournament', 'match', 'checked_in_at',)


class UserTrophyCaseSerializer(serializers.ModelSerializer):
    """ A UserTrophyCaseSerializer is used for UserTrophyCase Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your UserTrophyCase Model fields"""
        model = UserTrophyCase
        fields = ('id', 'usertrophycase_id', 'badges',)


class GetUserSubmitSerializer(serializers.ModelSerializer):
    """ A GetUserSubmitSerializer is used for Game Model """
    platform = serializers.StringRelatedField(many=True)
    games = serializers.StringRelatedField(many=True)
    icon_team = serializers.StringRelatedField(many=True)

    class Meta:
        """ Metaclass is used for changed the behaviour of Your get user submit Model fields"""
        model = GetUserSubmit
        fields = (
            'id', 'igl_username', 'avatar', 'platform', 'games', 'icon_team',)


class IGLNotificationSerializer(serializers.ModelSerializer):
    """ A IGLNotification Serializer is used for IGLNotification Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  IGLNotification Model fields"""
        model = IGLNotification
        fields = ("id", 'status', 'date', 'sender', 'type_of_notification', 'message',)


class UserIGLNotificationSerializer(serializers.ModelSerializer):
    """ A UserIGLNotification Serializer is used for UserIGLNotification Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  UserIGLNotification Model fields"""
        model = UserIGLNotification
        fields = ("id", 'user_id', 'user_notification')


class GlobalIndexHierarchySerializer(serializers.ModelSerializer):
    """ A GlobalIndexHierarchy Serializer  is used for GlobalIndexHierarchy Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  GlobalIndexHierarchy Model fields"""

        model = GlobalIndexHierarchy
        fields = ('id', 'start_index', 'end_index', 'global_index',)


class UserProfileSerializer(serializers.ModelSerializer):
    """ A UserProfile Serializer is used for User Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  User Model fields"""
        model = User
        fields = ('id', 'first_name', 'last_name', 'mobile_number', 'email',
                  'profile_image', 'IGL_Username', 'index_points',)


class GlobalIndexSerializer(serializers.ModelSerializer):
    """ A GlobalIndex Serializer is used for GlobalIndex Model """

    class Meta:
        """ Metaclass is used for changed the behaviour of Your  GlobalIndex Model fields"""

        model = GlobalIndex
        fields = ('id', 'user_id', 'igl_global_index')


class PGIUserSubmitSerializer(serializers.ModelSerializer):
    """ A PGIUserSubmit Serializer   is used for PGIUserSubmit Model """

    class Meta:
        model = PGIUserSubmit
        fields = (
            "id", "user_id", 'platforms', 'game', 'icon', 'is_first_time_login',)


class CompleteProfileSerializer(serializers.ModelSerializer):
    """ A CompleteProfileSerializer    is used for CompleteProfile Model """
    platform = PlatformSerializer(many=True)
    games = GameSerializer(many=True, )
    icon_team = IconSerializer(many=True, )

    class Meta:
        model = CompleteProfile
        """ Metaclass is used for changed the behaviour of Your  CompleteProfile Model fields"""
        fields = ('id', 'user_id', 'igl_username', 'avatar', 'platform', 'games', 'icon_team', 'is_first_time_login',)



class CompleteProfileUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompleteProfile
        """ Metaclass is used for changed the behaviour of Your  CompleteProfile Model fields"""
        fields = ('id', 'user_id', 'platform', 'games',)

class CreateProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompleteProfile
        """ Metaclass is used for changed the behaviour of Your  CompleteProfile Model fields"""
        fields = ('id', 'user_id', 'igl_username', 'avatar', 'platform', 'games', 'icon_team', 'is_first_time_login',)


class FriendRequestSerializer(serializers.ModelSerializer):
    """ A FriendRequest Serializer is used for FriendRequestSerializer Model """

    class Meta:
        model = FriendRequest
        fields = '__all__'


class GetAllFriendSerializer(serializers.ModelSerializer):
    """ A GetAllFriend Serializer  is used for CompleteProfile Model """

    icon_team = IconSerializer(many=True, )
    status = serializers.BooleanField(default=False)

    class Meta:
        model = CompleteProfile
        """ Metaclass is used for changed the behaviour of Your  CompleteProfile Model fields"""
        fields = ('id', 'user_id', 'igl_username', 'icon_team','status',)
