"""Import required module"""
from django.db import models
from IGL_account.models import User
from games.models import Platform, Tournament, Match, Game
from games.models import BadgesCategory
from icon.models import Icon


# Create your models here.

class UserPlatform(models.Model):
    """ A class is used to represent the UserPlatform """
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    platforms = models.ManyToManyField(Platform)

    def __str__(self):
        return str(self.user_id)

    def get_platforms(self):
        return self.platforms.all()


class UserGame(models.Model):
    """ A class is used to represent the UserGame """
    userplatform_id = models.ForeignKey(UserPlatform, on_delete=models.CASCADE)
    gammer_tag = models.CharField(max_length=255)
    game = models.ForeignKey(Game, on_delete=models.SET_NULL, null=True)
    display_image = models.ImageField(default='call-of-duty.jpeg', upload_to='game_logos', blank=True, null=True)

    def __str__(self):
        return self.gammer_tag


class UserMatchParticipant(models.Model):
    """ A class is used to represent the UserMatchParticipant """
    usermatchparticipant_id = models.ForeignKey(UserGame, on_delete=models.CASCADE)
    tournament = models.ForeignKey(Tournament, on_delete=models.CASCADE)
    match = models.ForeignKey(Match, on_delete=models.CASCADE)

    checked_in_at = models.DateTimeField()

    def __str__(self):
        return str(self.usermatchparticipant_id)


class UserTrophyCase(models.Model):
    """ A class is used to represent the class UserTrophyCase """
    usertrophycase_id = models.ForeignKey(UserMatchParticipant, on_delete=models.CASCADE)
    badges = models.ForeignKey(BadgesCategory, on_delete=models.CharField)

    def __str__(self):
        return str(self.badges)


####################################################################
class GetUserSubmit(models.Model):
    """ A class is used to represent the class GetUserProfile """
    igl_username = models.CharField(max_length=255)
    avatar = models.CharField(max_length=255, null=True)
    platform = models.ManyToManyField(Platform, blank=True)
    games = models.ManyToManyField(Game, blank=True)
    icon_team = models.ManyToManyField(Icon, blank=True)

    def __str__(self):
        return self.igl_username


###################################################################

class IGLNotification(models.Model):
    """ A class is used to represent the class IGLNotification """
    status = models.BooleanField()
    date = models.DateField(blank=True, null=True)
    sender = models.CharField(max_length=255, default='IGL Admin')
    type_of_notification = models.CharField(max_length=255)
    message = models.TextField()

    def __repr__(self):
        return self.type_of_notification


##################################################################

class UserIGLNotification(models.Model):
    """ A class is used to represent the class UserIGLNotification  """
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    user_notification = models.OneToOneField(IGLNotification, on_delete=models.CASCADE)


class GlobalIndexHierarchy(models.Model):
    """ A class is used to represent the class GlobalIndexHierarchy """

    start_index = models.IntegerField()
    end_index = models.IntegerField()
    global_index = models.FloatField()


class GlobalIndexCriteria(models.Model):
    """ A class is used to represent the class GlobalIndexCriteria """
    action = models.CharField(max_length=255)
    point = models.IntegerField()
    rule = models.CharField(max_length=255)

    def __repr__(self):
        return self.rule


class GlobalIndex(models.Model):
    """ A class is used to represent the class GlobalIndex """
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    igl_global_index = models.ForeignKey(GlobalIndexHierarchy, on_delete=models.CASCADE)

    def __str__(self):
        return str('igl_global_index')


class PGIUserSubmit(models.Model):
    """ A class is used to represent the class PGIUserSubmit """
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    platforms = models.ManyToManyField(Platform, blank=True)
    game = models.ManyToManyField(Game, blank=True)
    icon = models.OneToOneField(Icon, blank=True, on_delete=models.PROTECT)
    is_first_time_login = models.BooleanField(default=True)

    def __str__(self):
        return str(self.user_id)


class CompleteProfile(models.Model):
    """ A class is used to represent the class CompleteProfile """
    user_id = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    igl_username = models.CharField(max_length=255)
    avatar = models.CharField(max_length=255, null=True)
    platform = models.ManyToManyField(Platform, blank=True)
    games = models.ManyToManyField(Game, blank=True)
    icon_team = models.ManyToManyField(Icon, blank=True)
    is_first_time_login = models.BooleanField(default=True)

    def __str__(self):
        return self.igl_username


class FriendList(models.Model):
    """ A class is used to represent the FriendList """

    users1 = models.ManyToManyField(User, null=True)
    current_user = models.ForeignKey(User, related_name='owner', on_delete=models.CASCADE, null=True)

    def __str__(self):
        return str(self.current_user)

    @classmethod
    def make_friend(cls, current_user, new_friend):
        friend, create = cls.objects.get_or_create(
            current_user_id=current_user
        )
        print("test,.........", friend, create, current_user, new_friend)
        friend.users1.add(new_friend)
        print("add......")

    @classmethod
    def lose_friend(cls, current_user, new_friend):
        friend, create = cls.objects.get_or_create(
            current_user_id=current_user
        )
        print("test,.........", friend, create, current_user, new_friend)
        friend.users1.remove(new_friend)
        print("remove......")


class FriendRequest(models.Model):
    """ A class is used to represent the FriendRequest """

    sender = models.ForeignKey(User, null=True, related_name='sender1', on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, null=True, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.sender)
